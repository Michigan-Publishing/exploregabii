webpackHotUpdate(0,{

/***/ 4:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var netlify_cms__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3);
/* harmony import */ var netlify_cms__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(netlify_cms__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _editorComponents__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5);



netlify_cms__WEBPACK_IMPORTED_MODULE_0___default.a.registerEditorComponent(_editorComponents__WEBPACK_IMPORTED_MODULE_1__["FulcrumText"]);
netlify_cms__WEBPACK_IMPORTED_MODULE_0___default.a.registerEditorComponent(_editorComponents__WEBPACK_IMPORTED_MODULE_1__["FulcrumAudio"]);
netlify_cms__WEBPACK_IMPORTED_MODULE_0___default.a.registerEditorComponent(_editorComponents__WEBPACK_IMPORTED_MODULE_1__["FulcrumImage"]);
netlify_cms__WEBPACK_IMPORTED_MODULE_0___default.a.registerEditorComponent(_editorComponents__WEBPACK_IMPORTED_MODULE_1__["FulcrumVideo"]);
netlify_cms__WEBPACK_IMPORTED_MODULE_0___default.a.registerEditorComponent(_editorComponents__WEBPACK_IMPORTED_MODULE_1__["ExpandableBlockquote"]);
netlify_cms__WEBPACK_IMPORTED_MODULE_0___default.a.registerEditorComponent(_editorComponents__WEBPACK_IMPORTED_MODULE_1__["Game1"]);
netlify_cms__WEBPACK_IMPORTED_MODULE_0___default.a.registerEditorComponent(_editorComponents__WEBPACK_IMPORTED_MODULE_1__["Game2"]);
netlify_cms__WEBPACK_IMPORTED_MODULE_0___default.a.registerEditorComponent(_editorComponents__WEBPACK_IMPORTED_MODULE_1__["PieChart"]);
netlify_cms__WEBPACK_IMPORTED_MODULE_0___default.a.registerEditorComponent(_editorComponents__WEBPACK_IMPORTED_MODULE_1__["WordCloud"]);
netlify_cms__WEBPACK_IMPORTED_MODULE_0___default.a.registerEditorComponent(_editorComponents__WEBPACK_IMPORTED_MODULE_1__["MultimodalGame"]);
netlify_cms__WEBPACK_IMPORTED_MODULE_0___default.a.registerEditorComponent(_editorComponents__WEBPACK_IMPORTED_MODULE_1__["AboutTheAuthor"]);

/***/ })

})
//# sourceMappingURL=0.4dc1c78c5756b6ddaeca.hot-update.js.map