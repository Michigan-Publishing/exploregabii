webpackHotUpdate(0,{

/***/ 4:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var netlify_cms__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3);
/* harmony import */ var netlify_cms__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(netlify_cms__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _editorComponents__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5);


netlify_cms__WEBPACK_IMPORTED_MODULE_0___default.a.registerEditorComponent(_editorComponents__WEBPACK_IMPORTED_MODULE_1__["MapNavigation"]);

/***/ })

})
//# sourceMappingURL=0.5fe7b2de54df6cbd67c2.hot-update.js.map